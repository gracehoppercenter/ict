main()
{
    printf("\nHello, ACC CSC 215!\n");
}
